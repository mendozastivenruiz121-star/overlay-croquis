package com.example.overlaycroquis

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var pendingUri: Uri? = null

    private val pickImage = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            pendingUri = uri
            startOverlayIfAllowed()
        }
    }

    private val askNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "Elige una imagen para flotar sobre cualquier app.\n\n" +
                "• Arrastra con un dedo, pellizca con dos para cambiar el tamaño.\n" +
                "• Barra: opacidad.  👁: mostrar/ocultar.  🔒: la imagen deja pasar los toques para que dibujes debajo.\n" +
                "• ✕ cierra todo."
            textSize = 16f
        })
        root.addView(Button(this).apply {
            text = "Elegir imagen"
            setOnClickListener { pickImage.launch(arrayOf("image/*")) }
        })
        root.addView(Button(this).apply {
            text = "Detener overlay"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        })
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33) askNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    override fun onResume() {
        super.onResume()
        if (pendingUri != null && Settings.canDrawOverlays(this)) startOverlayIfAllowed()
    }

    private fun startOverlayIfAllowed() {
        val uri = pendingUri ?: return
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Activa \"Mostrar sobre otras apps\" y vuelve", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        pendingUri = null
        val i = Intent(this, OverlayService::class.java).setData(uri)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startForegroundService(i)
        moveTaskToBack(true) // te manda al inicio para que abras tu otra app
    }
}
