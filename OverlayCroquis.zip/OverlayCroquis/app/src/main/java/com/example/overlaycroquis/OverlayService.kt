package com.example.overlaycroquis

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var imageView: ImageView? = null
    private var imageParams: WindowManager.LayoutParams? = null
    private var panel: View? = null

    private var imageVisible = true
    private var locked = false
    private var opacity = 0.5f
    private var aspect = 1f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_TOGGLE -> { toggleVisible(); return START_NOT_STICKY }
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
        }
        startForegroundCompat()
        val uri: Uri = intent?.data ?: return START_NOT_STICKY
        loadImage(uri)
        if (panel == null) createPanel()
        return START_NOT_STICKY
    }

    // ---------- Imagen flotante ----------
    @SuppressLint("ClickableViewAccessibility")
    private fun loadImage(uri: Uri) {
        val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return
        aspect = bmp.height.toFloat() / bmp.width
        imageView?.let { wm.removeView(it) }

        val iv = ImageView(this).apply {
            setImageBitmap(bmp)
            scaleType = ImageView.ScaleType.FIT_XY
            alpha = opacity
        }
        val w = (resources.displayMetrics.widthPixels * 0.8f).toInt()
        val p = WindowManager.LayoutParams(
            w, (w * aspect).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            FLAGS_NORMAL, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 50; y = 300 }

        val scaler = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val nw = (p.width * d.scaleFactor).toInt().coerceIn(150, resources.displayMetrics.widthPixels * 3)
                p.width = nw; p.height = (nw * aspect).toInt()
                wm.updateViewLayout(iv, p)
                return true
            }
        })
        var lx = 0f; var ly = 0f
        iv.setOnTouchListener { _, e ->
            scaler.onTouchEvent(e)
            if (e.pointerCount == 1 && !scaler.isInProgress) {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        p.x += (e.rawX - lx).toInt(); p.y += (e.rawY - ly).toInt()
                        lx = e.rawX; ly = e.rawY
                        wm.updateViewLayout(iv, p)
                    }
                }
            } else { lx = e.rawX; ly = e.rawY }
            true
        }
        imageView = iv; imageParams = p
        wm.addView(iv, p)
        applyState()
    }

    private fun applyState() {
        val iv = imageView ?: return
        val p = imageParams ?: return
        iv.visibility = if (imageVisible) View.VISIBLE else View.GONE
        iv.alpha = opacity
        p.flags = if (locked) FLAGS_NORMAL or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE else FLAGS_NORMAL
        wm.updateViewLayout(iv, p)
    }

    private fun toggleVisible() { imageVisible = !imageVisible; applyState() }

    // ---------- Panel de control flotante ----------
    @SuppressLint("ClickableViewAccessibility")
    private fun createPanel() {
        fun btn(t: String, onClick: () -> Unit) = TextView(this).apply {
            text = t; textSize = 22f; setTextColor(Color.WHITE)
            setPadding(24, 12, 24, 12); setOnClickListener { onClick() }
        }
        val eye = btn("👁") { toggleVisible() }
        val lock = btn("🔓") { }
        lock.setOnClickListener { locked = !locked; lock.text = if (locked) "🔒" else "🔓"; applyState() }
        val close = btn("✕") { stopSelf() }
        val handle = btn("≡") { }

        val seek = SeekBar(this).apply {
            max = 100; progress = (opacity * 100).toInt()
            layoutParams = LinearLayout.LayoutParams(330, LinearLayout.LayoutParams.WRAP_CONTENT)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                    opacity = (v / 100f).coerceAtLeast(0.05f); imageView?.alpha = opacity
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply { setColor(0xCC222222.toInt()); cornerRadius = 48f }
            setPadding(16, 8, 16, 8)
            addView(handle); addView(eye); addView(lock); addView(seek); addView(close)
        }
        val root = FrameLayout(this).apply { addView(bar) }

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 120 }

        var lx = 0f; var ly = 0f
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lx = e.rawX; ly = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    p.x += (e.rawX - lx).toInt(); p.y += (e.rawY - ly).toInt()
                    lx = e.rawX; ly = e.rawY
                    wm.updateViewLayout(root, p)
                }
            }
            true
        }
        panel = root
        wm.addView(root, p)
    }

    // ---------- Notificación (también tiene botón mostrar/ocultar) ----------
    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Overlay", NotificationManager.IMPORTANCE_LOW))
        fun action(a: String, label: String): Notification.Action {
            val pi = PendingIntent.getService(
                this, a.hashCode(), Intent(this, OverlayService::class.java).setAction(a),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            return Notification.Action.Builder(null, label, pi).build()
        }
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_gallery)
            .setContentTitle("Imagen superpuesta activa")
            .addAction(action(ACTION_TOGGLE, "Mostrar/Ocultar"))
            .addAction(action(ACTION_STOP, "Cerrar"))
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    override fun onDestroy() {
        imageView?.let { wm.removeView(it) }
        panel?.let { wm.removeView(it) }
        super.onDestroy()
    }

    companion object {
        const val ACTION_TOGGLE = "toggle"
        const val ACTION_STOP = "stop"
        const val CHANNEL = "overlay"
        const val FLAGS_NORMAL = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    }
}
