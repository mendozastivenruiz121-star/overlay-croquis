# Overlay Croquis
1. Abre esta carpeta en Android Studio (Hedgehog o más nuevo) y deja que sincronice Gradle.
2. Conecta tu teléfono (depuración USB) y presiona Run, o Build > Build APK(s).
3. En la app: "Elegir imagen" -> concede "Mostrar sobre otras apps" -> vuelves y eliges la imagen otra vez si hace falta.
4. Te manda al inicio: abre tu app de dibujo/juego y verás la imagen y el panel flotante.
